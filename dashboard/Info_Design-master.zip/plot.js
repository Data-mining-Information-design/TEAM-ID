d3.csv("data.csv").then(makeChart);

function makeChart(sdata) {
    var Sdata = [];
    var Hdata = [];                //데이터를 저장할 배열을 준비
    var deposit = [];
    var label = [];
    var k =0;
    var d =0;
    var s = 0;
    var index = 30; //10일 보기
    for (let i = 0; i < index; i++) {              
        k = k + Number(sdata[sdata.length-1-index+i].Sy)
        s = s + Number(sdata[sdata.length-1-index+i].Hy)
        d = d + Number(sdata[sdata.length-1-index+i].deposit)
        Sdata.push(k);    //item1의 레이블 데이터만 추출
        Hdata.push(s);                 
        label.push(sdata[sdata.length-1-index+i].date);
        deposit.push(d);
                
    }    
    // var ctx = document.getElementById('art').getContext('2d');
    var myChart = new Chart('s_chart', {
        type: 'line',
        data: {
            labels: label,
            datasets: [{
                label: '최근 삼성주가 상승일 수(누적)',
                data: Sdata,
                borderColor: 'rgb(12, 77, 162)',                    
                backgroundColor: 'rgba(12, 77, 162, 0.6)',                
                fill: 'start'
            }],
        },
        options: {
            responsive: false,
            scales: {
				y: {
                    beginAtZero: true
                }
			}
        }
    });
    var myChart = new Chart('h_chart', {
        type: 'line',
        data: {
            labels: label,
            datasets: [{
                label: '최근 하이닉스주가 상승일 수(누적)',
                data: Hdata,
                borderColor: 'rgb(231, 26, 57)',                    
                backgroundColor: 'rgba(231, 26, 57, 0.6)',                fill: 'start'
            }
            /*{
                label: '예금 금리',
                data: deposit,
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(255, 206, 86, 0.2)',
                    'rgba(75, 192, 192, 0.2)',
                    'rgba(153, 102, 255, 0.2)',
                    'rgba(255, 159, 64, 0.2)'
                ],
                fill: 'start'
            }*/]
        } ,
        options: {
            responsive: false,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}