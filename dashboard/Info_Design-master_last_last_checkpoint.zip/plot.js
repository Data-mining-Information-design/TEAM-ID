d3.csv("data.csv").then(makeChart);

function makeChart(sdata) {
    var Sdata = [];
    var Hdata = [];                //데이터를 저장할 배열을 준비
    var deposit = [];
    var label = [];
    var Spre = [];
    var Sori = [];
    var Spori = [];
    var Hori = [];
    var Hpori = [];
    var Hpre = [];
    var k =0;
    var d =0;
    var s = 0;
    var sp = 0;
    var hp = 0;
    var index = 30; //10일 보기
    for (let i = 0; i < index; i++) {              
        k = k + Number(sdata[sdata.length-1-index+i].Sy)
        s = s + Number(sdata[sdata.length-1-index+i].Hy)
        d = d + Number(sdata[sdata.length-1-index+i].deposit)
        hp = hp + Number(sdata[sdata.length-1-index+i].Hpre)
        sp = sp + Number(sdata[sdata.length-1-index+i].Spre)
        Sdata.push(k);    //item1의 레이블 데이터만 추출
        Hdata.push(s);
        Sori.push(sdata[sdata.length-1-index+i].Sy);
        Spori.push(sdata[sdata.length-1-index+i].Spre);
        Hori.push(sdata[sdata.length-1-index+i].Hy);
        Hpori.push(sdata[sdata.length-1-index+i].Hpre);
        label.push(sdata[sdata.length-1-index+i].date);
        Spre.push(sp);
        Hpre.push(hp);
        deposit.push(d);
                
    }    
    // var ctx = document.getElementById('art').getContext('2d');
    var myChart = new Chart('h_chart', {
        data: {
            datasets: [{
                    type: 'line',
                    label: '실제',
                    data: Hdata,
                    borderColor: 'rgb(231, 26, 57)',
                    backgroundColor: 'rgba(231, 26, 57, 0)',
                    steppedLine: true
                },{   
                    type: "bar",
                    label: '예측',
                    data: Hpori,
                    backgroundColor: 'rgba(231, 26, 57, 0.5)'
                },{   
                    type: "line",
                    label: '실제',
                    data: Hori,
                    borderColor: 'rgb(231, 26, 57, 0.5)'
            }],
            labels: label
        },
        options: {
            responsive: false,
            scales: {
                y: {
                    beginAtZero: true
                }
            },
            legend: {
                display: true,
                position: 'bottom',
            }
        }
    });
    var myChart = new Chart('s_chart', {
        type: 'line',
        data: {
            labels: label,
            datasets: [{
                label: '실제',
                data: Sdata,
                borderColor: 'rgb(12, 77, 162)',
                backgroundColor: 'rgba(231, 26, 57, 0)',
                steppedLine: true
            },
            {
                label: '예측',
                data: Spre,
                borderColor: 'rgba(12, 77, 162, 0.5)',
                backgroundColor: 'rgba(231, 26, 57, 0)',
                borderDash: [8,4],
                steppedLine: true              
            }],
        },
        options: {
            responsive: false,
            scales: {
				y: {
                    beginAtZero: true
                }
			},
            legend: {
                display: true,
                position: 'bottom',
            }
        }
    });
}