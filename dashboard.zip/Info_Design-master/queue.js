! function() {
    function n(n) {
      function e() {
        for (; i = a < c.length && n > p;) {
          var u = a++,
            e = c[u],
            o = t.call(e, 1);
          o.push(l(u)), ++p, e[0].apply(null, o)
        }
      }
  
      function l(n) {
        return function(u, t) {
          --p, null == s && (null != u ? (s = u, a = d = 0 / 0, o()) : (c[n] = t, --d ? i || e() : o()))
        }
      }
  
      function o() {
        null != s ? m(s) : f ? m(s, c) : m.apply(null, [s].concat(c))
      }
      var r, i, f, c = [],
        a = 0,
        p = 0,
        d = 0,
        s = null,
        m = u;
      return n || (n = 1 / 0), r = {
        defer: function() {
          return s || (c.push(arguments), ++d, e()), r
        },
        await: function(n) {
          return m = n, f = !1, d || o(), r
        },
        awaitAll: function(n) {
          return m = n, f = !0, d || o(), r
        }
      }
    }
  
    function u() {}
    var t = [].slice;
    n.version = "1.0.7", "function" == typeof define && define.amd ? define(function() {
      return n
    }) : "object" == typeof module && module.exports ? module.exports = n : this.queue = n
  }();